Delivery A v10 — Mobile "Scan Logbook" review now readable
============================================================

WHAT'S FIXED IN v10:
✅ "Scan Logbook with AI" review dialog is now MOBILE-RESPONSIVE
   - Was: 7-column table crammed side-by-side → only 1-2 characters
     visible per input on phone.
   - Now: On phones (<768px), each detected item is a full-width CARD with
     properly labeled fields, taking up the whole screen width. You can
     actually READ the product names, quantities, etc.
   - Desktop layout stays the same (spacious table).

MOBILE CARD LAYOUT PER ITEM:
   ✅ Item 1
   Name:      [                                    ]
   Qty  [        ]     Unit [                     ]
   Expiry:    [                                    ]
   Category [           ]  Storage [               ]

OTHER SCANNERS CHECKED — already OK:
✅ Voice Scanner (Add by Voice) — already uses expandable cards
✅ Supplier Invoice Scanner    — already uses expandable cards
✅ Snap Label                  — single-item form, mobile-friendly already
✅ HACCP Temp Log Scanner      — flex-based rows, auto-shrink on mobile

REMOVED (from v9):
- "Shelf" column from the printable logbook PDF
- Product column widened 24% → 34%

CARRIED FROM v1-v9:
✅ 7-column PDF logbook: # · Product (34%) · Qty · Unit · Expiry · Storage · Initials
✅ Portrait / Landscape orientation toggle (Landscape default)
✅ Wider (taller) rows: 28pt portrait / 30pt landscape
✅ Standalone new-tab print (bypasses iOS Safari CSS quirks)
✅ 5-language framework (English/Hindi/Gujarati/Punjabi/Spanish)
✅ Android install button with manual fallback
✅ Recipe servings default = 1

HOW TO DEPLOY:
1. Tap "Save to GitHub" → main branch → Save
2. Wait 1-2 min for Vercel
3. Refresh https://shelfwise.co.in on your phone

TO TEST THE FIX:
1. Log in on your phone
2. Dashboard → Scan Logbook → take a photo of a logbook
3. Wait for AI to detect items
4. The review dialog should now show each item as a big card
   with full-width Name, Qty, Unit, Expiry, Category, Storage inputs
5. You can actually SEE and EDIT the values properly!
