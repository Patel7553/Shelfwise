Delivery A v11 — Bulk delete + Added Today card + Duplicate detection
======================================================================

3 NEW FEATURES IN v11:

1. MULTI-SELECT DELETE IN INVENTORY
   ✅ Checkbox column at the LEFT of the inventory table
   ✅ Master checkbox in header to select ALL / DESELECT ALL
   ✅ Rows highlighted emerald when selected
   ✅ Red "Delete N selected" button appears in the toolbar when items are selected
   ✅ Confirmation prompt before deleting
   ✅ Bulk deletes one-by-one via the existing DELETE API
   ✅ Auto-refreshes inventory + stats after done

2. "ADDED TODAY" CARD ON DASHBOARD
   ✅ New card below "Urgent Items" showing everything added TODAY
   ✅ Auto-resets at midnight (uses today's start/end for filtering)
   ✅ Shows: product image, name, qty/unit, storage, expiry, added by, time
   ✅ Sorted most-recent first
   ✅ Shows up to 8 items with "+ N more" if more exist
   ✅ Empty state with hints: "Nothing added yet today. Use Voice, Snap Label..."
   ✅ Click any item to jump to inventory

3. DUPLICATE DETECTION POPUP
   ✅ When adding a product (manually, voice, snap, or logbook scan) that
      matches an existing product by:
        - Name (case-insensitive, trimmed)
        - Quantity (exact)
        - Expiry date (same day)
        - Initials / prepared by (if both are set)
   ✅ Shows a warning popup: "⚠️ This item looks like a duplicate..."
   ✅ Lists up to 5 conflicting items
   ✅ User can:
        [OK]     = Add anyway (create duplicate)
        [Cancel] = Stop and let them uncheck manually
   ✅ Works in:
        - Manual Add Product form
        - Snap Label (single item)
        - Voice Scanner (bulk)
        - Scan Logbook with AI (bulk)

CARRIED FROM v1-v10:
✅ Logbook PDF (7 clean columns, landscape default, wider rows)
✅ Portrait/Landscape orientation toggle
✅ Mobile-friendly Scan Logbook review (card layout on phones)
✅ 5-language framework
✅ Android install fallback
✅ Recipe servings default = 1

DEPLOY:
1. Tap "Save to GitHub" → main branch → Save
2. Wait 1-2 min for Vercel
3. Refresh https://shelfwise.co.in

TO TEST:
1. Login → Dashboard → look for the new "Added Today" card
2. Add a product manually OR voice-scan an item that already exists
   → duplicate warning appears
3. Go to Inventory → tick multiple items → red "Delete N selected" button
   appears → tap → confirm → items deleted in one go
