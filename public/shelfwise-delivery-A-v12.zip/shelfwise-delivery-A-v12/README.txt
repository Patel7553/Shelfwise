Delivery A v12 — 3 UX fixes
============================

FIXED:
✅ Bulk delete now shows a BEAUTIFUL styled dialog (not the ugly iOS bubble)
   - Lists the first 6 items being deleted with name + qty + expiry
   - "…and N more" if selection is bigger
   - Amber tip suggesting the Dispose flow if user wants to track waste
   - Big red "Yes, delete N" button OR Cancel

✅ Added Today items are now CLICKABLE
   - Tap any item in the "Added Today" card on Dashboard
   - Opens the full product edit dialog — see image, allergens, cost, notes, EVERYTHING
   - You can also edit / save changes from there

✅ Dashboard widgets stay saved
   - Fixed the useEffect dep so Settings dialog properly syncs when settings load
   - Previously widgets could revert after external settings changes; now they persist

STILL TO INVESTIGATE (needs your input):
❓ Temp Log AI scan not detecting items
   - Please tell me: what happens when you try? Does it say "AI is reading..."
     forever? Does it say "no items detected"? Does it show a different error?
   - Also send a screenshot of the temp log you're photographing so I can
     see if it's a text-recognition issue or an API issue.

CARRIED FROM v1-v11:
- 5-language framework
- Android install button + fallback
- Recipe servings default 1
- Logbook PDF (7 columns, orientation toggle, wider rows)
- Mobile-friendly Scan Logbook review
- Multi-select delete with checkbox
- Recent items today card
- Duplicate detection popup

DEPLOY: Tap "Save to GitHub" → main branch → Save.
