Delivery A v13 — Kitchen name bug fixed + Bulk dispose with reasons
=====================================================================

BUG FIX: Kitchen name no longer resets to "ShelfWise"
------------------------------------------------------
ROOT CAUSE: When the Settings dialog opened before settings finished loading
from the backend, the internal 'name' state was set to ''. Clicking Save then
sent `kitchenName: ''` which overwrote "bupa" in the DB. Occasionally the
backend rejected the empty write, so on next reload the name came back — but
your dashboard widget selections were sent BEFORE the failed name save so
they got lost too.

FIX: The Settings save() now only includes fields the user actually filled in.
     If `name` is empty (still loading), we skip kitchenName entirely — the
     backend keeps the existing value. Same for other optional fields.

NEW: BULK DISPOSE WITH WASTE REASONS
-------------------------------------
When you tick multiple items in Inventory and tap "Delete N selected", you
now see a dialog with:

   • Item preview (first 6 items)
   • 6 reason buttons (same as single-item dispose):
        ✅ Used up (consumed normally) — NOT counted as waste
        ⏰ Expired
        🤢 Spoiled / gone off
        💥 Damaged / dropped
        📦 Overstock / not needed
        ❓ Other
   • "Delete N · no waste log" (hard delete without tracking) — the red button
   • Cancel

Tapping a reason:
   - Applies THAT reason to ALL selected items
   - Logs each to waste analytics (except "Used up")
   - Deletes the products
   - Shows success toast

This gives you proper waste tracking for bulk operations.

CARRIED FROM v1-v12:
- Multi-select delete in Inventory
- Added Today card on Dashboard (clickable → opens product edit)
- Duplicate detection popup
- Mobile-friendly Scan Logbook review
- Logbook PDF (7 cols, orientation toggle, wider rows)
- 5-language framework
- Android install button + fallback
- Recipe servings default 1

DEPLOY:
Tap "Save to GitHub" → main branch → Save → wait 1-2 min → refresh.

TO TEST:
1. Open Settings → toggle a dashboard card → Save
2. Kitchen name should STAY as "bupa" (not revert to ShelfWise)
3. Dashboard card should show up AND persist across reload
4. Go to Inventory → select 3 items → "Delete 3 selected" → reason picker appears
5. Pick "Expired" → 3 items disposed & logged as waste
