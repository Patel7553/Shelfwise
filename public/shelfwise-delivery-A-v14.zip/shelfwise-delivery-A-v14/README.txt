Delivery A v14 — Kitchen name persistence FINAL fix
====================================================

BUG:
Even after v13, saving Dashboard cards from Settings occasionally caused the
kitchen name to reset to "SHELFWISE" (default fallback).

ROOT CAUSE:
The Settings dialog's local 'name' state could go stale (e.g., dialog opened
before settings finished loading via API). Even though v13 skipped empty
kitchenName, it still SENT the state value which could be an outdated version.

FINAL FIX (v14):
Settings save() now ONLY sends a field if the user actually CHANGED it from
what's currently in settings. Not just non-empty — actually DIFFERENT.

Example:
  - Current settings.kitchenName = "bupa"
  - User opens settings, doesn't touch name field
  - Local state: name = "bupa" (loaded via useEffect)
  - Save clicked → compare name ("bupa") to settings.kitchenName ("bupa") 
    → SAME → skip → NOT sent to backend → DB keeps "bupa" ✅

If for any reason state goes stale (name="" or old value):
  - Compare "" to "bupa" → different → BUT `if (trimmedName && ...)` — empty
    trimmedName also skipped
  - Result: kitchenName NEVER accidentally overwritten

Also added settings.kitchenName + kitchenType + currency + alertEmail to the
useEffect dependency array so the dialog ALWAYS re-syncs when settings loads.

CARRIED FROM v1-v13:
- 5-language framework
- Android install fallback  
- Recipe servings default = 1
- Logbook PDF (orientation toggle, wider rows, 7 columns)
- Mobile-friendly Scan Logbook review
- Multi-select delete with reasons (Used up / Expired / Spoiled / etc.)
- Added Today dashboard card (clickable → edit dialog)
- Duplicate detection popup

DEPLOY: Tap "Save to GitHub" → main → Save → wait 1-2 min → refresh.

AFTER DEPLOY:
1. Open Settings → toggle a dashboard card → Save
2. Kitchen name STAYS as "BUPA" 
3. Close app, reopen → still "BUPA"
4. Dashboard card change persists

If ANY future field seems to reset unexpectedly, we can extend this
"only send if changed" logic to more fields.
