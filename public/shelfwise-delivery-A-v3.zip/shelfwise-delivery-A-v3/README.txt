==========================================
ShelfWise — Delivery A (v3 — LOGBOOK FIX)
==========================================

FIXED IN v3
-----------
✅ Logbook PDF no longer cuts off on right side (removed Notes column,
   fixed column widths to sum to exactly 100%, added table-layout: fixed).
✅ Logbook PDF fits on 1 A4 page (default rows now 20 instead of 25,
   tighter page margins 10mm/8mm, page-break-inside: avoid on rows).
✅ Header layout cleaner — Date, Shift, Logged-by on separate rows.
✅ Column headers word-wrap properly instead of overflowing.

CARRIED FROM v2 / v1
--------------------
✅ 5-language UI framework (English/Hindi/Gujarati/Punjabi/Spanish)
✅ Android install button with manual fallback modal
✅ Recipe Generator default servings = 1
✅ Language switcher on Login page + Settings dialog

FILES TO REPLACE (overwrite existing)
-------------------------------------
  • app/lib/i18n.js                     (NEW file — create it)
  • app/components/LanguageSwitcher.js  (NEW file — create it)
  • app/components/InstallAppPrompt.js  (OVERWRITE)
  • app/page.js                         (OVERWRITE — has all fixes)
  • app/login/page.js                   (OVERWRITE)

HOW TO INSTALL
--------------
1. Unzip.
2. Drag files into VS Code at matching paths.
3. Overwrite when prompted.
4. Commit + push → Vercel deploys.

HOW TO TEST THE LOGBOOK FIX
---------------------------
1. Open ShelfWise → Dashboard.
2. Click "Print Logbook".
3. Click "Print / Save PDF".
4. In Chrome print dialog:
   - Destination: Save as PDF
   - Layout: Portrait (default)
   - Paper size: A4 (default)
   - Margins: Default (or None — either works)
5. Save → open the PDF.

You should now see:
✅ All 8 columns fit within the page width (no cut-off on right)
✅ 20 rows fit on one A4 page
✅ Clean 2-column header at top
✅ Sheet 1 of 1 (or Sheet 1 of N for multi-day)

NEXT PENDING DECISION
---------------------
Name change: Kitcheye vs ChefCompas (or your own suggestion).
Once decided, Delivery B will:
  - Rebrand entire app
  - Add 22 more EU languages (24 EU total + Hindi/Gujarati/Punjabi = 27 langs)
  - Wrap Dashboard tiles, HACCP screens, Rota, Recipes with T() calls
