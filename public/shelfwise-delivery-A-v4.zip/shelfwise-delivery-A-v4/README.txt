Delivery A v4 — LOGBOOK OVERLAP FIX
====================================

WHAT WAS WRONG IN v3:
- The Date/Shift/Logged-by table on the right was OVERLAPPING the Kitchen name
  block on the left. Print CSS accidentally added borders to the header info table.

WHAT'S FIXED IN v4:
✅ Print CSS is now SCOPED to the data table only (class: logbook-data-table).
   The header info block is completely untouched by the border rules.
✅ Header layout uses simple flex + divs — no nested tables, no overlap possible.
✅ Right column has fixed 250px min-width so it never squeezes.
✅ Column headers ("Storage", "Name/Initials") use word-break: keep-all so they
   don't split mid-word.
✅ Column header font slightly smaller (8.5pt) for better fit.

The 8 data columns still sum to exactly 100%: 5+27+9+9+15+12+11+12 = 100.
20 rows still fit on 1 A4 portrait page.

CARRIED FROM v1/v2/v3:
- 5-language framework
- Android install fallback
- Recipe servings default 1

DEPLOY:
- Just use "Save to Github" button on the Emergent chat input
- Pick main branch — this time no conflict since your last force-push
- Vercel deploys within 1-2 min
