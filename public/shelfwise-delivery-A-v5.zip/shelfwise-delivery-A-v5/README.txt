Delivery A v5 — LOGBOOK PDF FIXED (top blank space + word wrap)
================================================================

WHAT WAS STILL WRONG IN v4:
1. Big empty white space at TOP of the PDF (hidden elements were reserving space)
2. Column headers still breaking: "Storag/e" and "Name/Initials" wrapped ugly

WHAT'S FIXED IN v5:
✅ Print sheet is now position: absolute at top:0 left:0 during print.
   Kills the blank top space completely. Content starts at very top of A4.
✅ Column headers shortened: "Shelf/Loc." → "Shelf", "Name/Initials" → "Initials"
   Less text = no wrapping.
✅ Column widths rebalanced: Storage from 12% to 14%, so "Storage" fits.
✅ Column headers use white-space:normal + font 7.5pt so they never break mid-word.
✅ Tighter cell padding (2.5px 3px) — more content per page.
✅ Slightly wider A4 print area: margin reduced 10mm→8mm horizontal, 8mm→6mm vertical.

FINAL 8 columns (widths sum to 100%):
  # (5%) · Product (24%) · Qty (8%) · Unit (8%) · Expiry (15%) 
  · Storage (14%) · Shelf (12%) · Initials (14%)

CARRIED FROM v1-v4:
- 5-language framework (English/Hindi/Gujarati/Punjabi/Spanish)
- Android install fallback
- Recipe servings default 1
- Header no longer overlaps (v4 fix retained)

DEPLOY:
- Tap "Save to GitHub" → pick main branch → Save
- Should be a normal push (no conflict this time)
- Vercel deploys in 1-2 min
- Refresh https://shelfwise.co.in on your phone

TO TEST:
- Log in → Dashboard → Print Logbook → Save as PDF
- Should now show: clean top, no blank space, all 8 columns visible,
  headers on 1 line, 20 rows fit on 1 A4 page.
