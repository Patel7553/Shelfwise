Delivery A v6 — BULLETPROOF LOGBOOK PDF
========================================

ROOT CAUSE (finally identified):
Mobile Safari's "Save as PDF" doesn't fully respect @media print CSS the way
Chrome does. My previous fixes (v3/v4/v5) worked in desktop Chrome but not
in iOS Safari — the modal/parent DOM was still reserving space.

DEFINITIVE FIX IN v6:
Instead of trying to hide the app modal with CSS, we now generate a
completely standalone HTML document (with all inline styles, no React, no
Tailwind, no modal) and open it in a NEW TAB. The new tab has ZERO parent
CSS to interfere. It auto-triggers the print dialog after 300ms.

This works identically on:
✅ Desktop Chrome / Edge / Firefox / Safari
✅ Android Chrome
✅ iOS Safari  (was the problematic one — now fixed)

WHEN YOU TAP "Print / Save PDF":
1. A new browser tab opens with just the printable HTML
2. Print dialog appears automatically after ~300ms
3. Choose "Save as PDF" → done
4. Close the new tab

FEATURES OF THE NEW PDF:
- 20 rows per A4 page (or however many you set)
- Multi-day prints paginate with clean page breaks
- Kitchen name + Date/Shift/Logged-by header at TOP (no blank space)
- 8 columns: # / Product / Qty / Unit / Expiry / Storage / Shelf / Initials
- Table borders, alternating row colors, professional look
- 8mm/6mm A4 margins (max usable print area)
- Tip box explaining "Scan Logbook" feature

FALLBACK:
If a browser blocks the new tab (rare), we fall back to a data-URL
approach that opens the print HTML in the same tab.

CARRIED FROM v1-v5:
✅ 5-language framework
✅ Android install fallback
✅ Recipe servings default 1

DEPLOY:
- Tap "Save to GitHub" → main branch → Save
- Vercel deploys in 1-2 min

HOW TO TEST:
1. Deploy → open https://shelfwise.co.in
2. Log in → Dashboard → tap "Print Logbook"
3. Tap "Print / Save PDF" → a NEW TAB opens
4. Print dialog appears → pick "Save as PDF"
5. Save → open the PDF → should be PERFECT this time.
