Delivery A v8 — Logbook Orientation + Wider Rows
=================================================

NEW IN v8:
✅ Portrait / Landscape toggle in the Print Logbook dialog
   - Big [📄 Portrait] [📃 Landscape] buttons — one-tap switch
   - Landscape is now the DEFAULT (per your request — more roomy for handwriting)
✅ Wider (taller) rows for handwriting:
   - Portrait: 28pt row height (was ~20pt) — noticeably taller
   - Landscape: 30pt row height — even more room
✅ Dimensions auto-adjust to selected orientation:
   - Landscape: rowsPerDay defaults to 15 · @page A4 landscape · body font 10pt
   - Portrait:  rowsPerDay defaults to 18 · @page A4 portrait  · body font 9pt
✅ Column widths recalculated so 8 columns always sum to 100% and stretch
   edge-to-edge regardless of orientation

CARRIED FROM v7:
✅ Standalone new-tab print approach (bypasses iOS Safari CSS quirks)
✅ No blank space top or right
✅ 8 clean columns: # / Product / Qty / Unit / Expiry / Storage / Shelf / Initials

CARRIED FROM v1-v7:
✅ 5-language framework
✅ Android install fallback
✅ Recipe servings default 1

HOW TO USE:
1. Deploy via Save to GitHub → main branch
2. Log in → Dashboard → Print Logbook
3. See the new "Page orientation" toggle — pick 📃 Landscape (default) or 📄 Portrait
4. Rows/day updates automatically
5. Tap Print/Save PDF → new tab opens with sheet in your chosen orientation
6. Save as PDF or print

TIP: Landscape is BETTER for handwriting because rows are ~50% taller.
     Portrait is better if you have long product names that need more horizontal space.
