Delivery A v9 — Logbook: Shelf column removed + Product column bigger
======================================================================

NEW IN v9:
✅ Removed "Shelf" column (as requested)
✅ Product column now 34% wide (was 24%) — 42% more space for product names
✅ Table now has 7 clean columns:
    # (5%) · Product (34%) · Qty (9%) · Unit (9%) · Expiry (16%) · Storage (14%) · Initials (13%)
    Total: 100% — stretches edge-to-edge

CARRIED FROM v8:
✅ Portrait / Landscape orientation toggle (landscape = default)
✅ Wider (taller) rows: 28pt portrait / 30pt landscape
✅ Auto-adjusted rows-per-day: 18 portrait, 15 landscape

CARRIED FROM v7:
✅ Standalone new-tab print HTML (works on iOS Safari + Chrome + Android)
✅ No blank top/right space

CARRIED FROM v1-v6:
✅ 5-language framework
✅ Android install fallback
✅ Recipe servings default = 1

HOW TO DEPLOY:
1. Tap "Save to GitHub" → main branch → Save
2. Wait 1-2 min for Vercel
3. Refresh https://shelfwise.co.in on your phone

TO USE THE NEW LOGBOOK:
1. Dashboard → Print Logbook
2. Toggle [📄 Portrait] or [📃 Landscape]
3. Tap Print/Save PDF → new tab opens
4. Save as PDF or print

RECOMMENDED FOR WRITING:
📃 Landscape gives more horizontal space PLUS taller rows PLUS bigger fonts.
   Best for handwriting product names + quantities.

📄 Portrait fits more rows per page (18 vs 15) if you have many items.
