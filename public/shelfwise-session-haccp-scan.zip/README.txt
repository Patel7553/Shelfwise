╔══════════════════════════════════════════════════════════════════╗
║  ShelfWise — Fix Bundle                                          ║
║  Kitchen name CENTERED + UPPERCASE · Logbook name col + 100 rows ║
║  NEW: AI Scan HACCP temperature log photo → auto-add readings    ║
╚══════════════════════════════════════════════════════════════════╝

FIVE FIXES FROM YOUR FEEDBACK
──────────────────────────────

  1) 🏠 KITCHEN NAME — now truly centred on every screen
     Before: mobile showed name on left, only desktop centred
     After:  centred on ALL devices (phone, tablet, laptop)

  2) 🔠 KITCHEN NAME — always UPPERCASE in header
     Before: whatever you typed ("bupa") showed as typed
     After:  displayed as "BUPA" regardless of what you typed
             (your original setting is unchanged, just the display)

  3) 📋 LOGBOOK — added "Name / Initials" column
     Now every row has a column for staff initials → per-row accountability
     for HACCP + inspector-ready traceability.

  4) 📋 LOGBOOK — rows can now go up to 100 per day (was 50 max)
     Rows/day dropdown accepts 5-100 now.
     Also: if you set 30+ items, they'll still fit on ONE sheet at
     smaller row height — the print is auto-scaled.

  5) 🌡️ HACCP — NEW: SCAN paper temperature log with AI ⭐
     A clipboard on the wall with multiple fridge names + morning/evening
     temperature columns is standard in every kitchen. Now:

        1. Snap or upload a photo of the clipboard sheet
        2. AI reads EVERY reading in one pass
           - Location (Fridge 1, Freezer 2, Walk-in, Hot Hold, etc.)
           - Temperature in °C
           - Time of day (morning / evening / other)
           - Initials (if visible)
           - PASS/FAIL auto-flagged based on UK safe ranges
        3. Review the extracted readings in an editable list
        4. Untick any wrong ones, edit fields inline
        5. Tap "Save X readings" → all logged in HACCP > Temperatures
           tab instantly, appear in the 30-day PDF report

     Where to find: Compliance → Temperatures tab → new green
     "📸 Scan temp log (AI)" button next to "Log temperature".

═══════════════════════════════════════════════════════════════════
DEPLOYMENT — 2 STEPS (5 min)
═══════════════════════════════════════════════════════════════════

STEP 1 — REPLACE FILES IN VS CODE
  Drag-drop these files (OVERWRITE):
    ✓ app/page.js
    ✓ app/api/[[...path]]/route.js

  If you haven't deployed prior sessions:
    ✓ supabase/migration-9-haccp.sql          (NEW)
    ✓ supabase/migration-10-weekly-digest.sql (NEW)
    ✓ vercel.json                             (NEW at repo root)

STEP 2 — COMMIT + SYNC
  Commit message: "Fix header + logbook + AI scan HACCP temperature log"
  Sync → Vercel deploys in 2-3 min

═══════════════════════════════════════════════════════════════════
HOW TO USE THE NEW AI TEMPERATURE SCANNER
═══════════════════════════════════════════════════════════════════

Physical clipboard sheet example (any layout works):

  ┌───────────────────────────────────────────────────────┐
  │  Date: 05/07/26                                       │
  │  ┌──────────────┬─────────┬─────────┬────────┐        │
  │  │ Location     │ AM temp │ PM temp │ Init.  │        │
  │  ├──────────────┼─────────┼─────────┼────────┤        │
  │  │ Fridge 1     │  4.0    │  5.2    │  PS    │        │
  │  │ Fridge 2     │  3.8    │  4.5    │  PS    │        │
  │  │ Walk-in      │  2.5    │  3.1    │  AJ    │        │
  │  │ Freezer 1    │ -20.0   │ -19.5   │  PS    │        │
  │  │ Hot Hold     │  68     │  71     │  AJ    │        │
  │  └──────────────┴─────────┴─────────┴────────┘        │
  └───────────────────────────────────────────────────────┘

Snap that → tap "Extract with AI" → 10 readings appear (5 fridges × 2
times). Each pre-classified as PASS/FAIL. Save all in one click.

Saves you from typing 10 readings twice a day = 140 taps/week.

═══════════════════════════════════════════════════════════════════
COST NOTE
═══════════════════════════════════════════════════════════════════

Each AI scan of the temperature sheet = ~1 GPT-4o call (~£0.02).
Twice-daily scan = £0.04/day = ~£1.20/month.
Payback = 5 min/day saved × 20 days × £15/hr = £25/month worth.

═══════════════════════════════════════════════════════════════════
QUESTIONS?
═══════════════════════════════════════════════════════════════════

Kitchen name still not centred?
  → Refresh the page after Vercel deploys (~2 min)
  → Hard reload: Cmd+Shift+R (Mac) or Ctrl+Shift+F5 (Windows)

Kitchen name is CENTRE but not UPPERCASE?
  → Same fix — hard reload the app

Temperature scan says "AI failed to read"?
  → Photo was too blurry, dark, or angled. Retake with:
    - Clipboard flat on the table
    - Camera directly above (no angle)
    - Bright light, avoid shadow
    - Rotate if it comes out sideways using the ↻ buttons

Wrong temperatures in the AI output?
  → Edit inline before saving. The AI is 90% accurate on printed
    or clear handwriting — messy handwriting = manual fix.

— ShelfWise
