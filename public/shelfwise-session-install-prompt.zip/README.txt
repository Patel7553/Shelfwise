╔══════════════════════════════════════════════════════════════════╗
║  ShelfWise — Install App on Home Screen (PWA prompt)             ║
║  Smart Android + iOS install banner                              ║
╚══════════════════════════════════════════════════════════════════╝

WHAT THIS DOES:
───────────────
When users visit shelfwise.co.in they'll see a banner offering to install
the app on their home screen. It behaves differently per platform:

  📱 Android / Chrome / Desktop Chrome:
     - Browser fires `beforeinstallprompt` event → we catch it
     - One-tap "Install" button triggers the native install prompt
     - Icon added to home screen in ~2 seconds
     - Works like a native app: fullscreen, no browser chrome, offline-ready

  🍎 iPhone / iPad Safari:
     - Apple blocks all programmatic install prompts (their rule)
     - We show a friendly step-by-step modal:
       1. Tap Share button
       2. Tap "Add to Home Screen"
       3. Tap "Add"
     - With ⚠ warning that Chrome/Firefox on iOS can't install
       (Safari only — user must switch browsers first)

  ✅ Already installed:
     - Detected via `display-mode: standalone`
     - Banner hides completely — no annoyance

  ✕ Dismissed:
     - Remembered for 30 days in localStorage
     - No spamming users

WHERE THE BANNER APPEARS:
─────────────────────────
  1) LOGIN PAGE (before login) — big friendly card below the form,
     for first-time visitors who don't have an account yet

  2) MAIN APP (after login) — compact strip below the header on
     every page, for existing users who visited on their phone
     but haven't installed yet

═══════════════════════════════════════════════════════════════════
DEPLOYMENT — 2 STEPS (3 min)
═══════════════════════════════════════════════════════════════════

STEP 1 — REPLACE FILES IN VS CODE
  Drag-drop these files (OVERWRITE):
    ✓ app/page.js
    ✓ app/login/page.js
    ✓ components/InstallAppPrompt.js  (NEW FILE)

  If you haven't deployed prior sessions, ALSO include:
    ✓ app/api/[[...path]]/route.js
    ✓ supabase/migration-9-haccp.sql          (NEW)
    ✓ supabase/migration-10-weekly-digest.sql (NEW)
    ✓ vercel.json                             (NEW at repo root)

STEP 2 — COMMIT + SYNC
  Commit message: "Add PWA install prompt (Android + iOS)"
  Sync → Vercel deploys in 2-3 min

═══════════════════════════════════════════════════════════════════
HOW TO TEST
═══════════════════════════════════════════════════════════════════

DESKTOP CHROME:
  1. Open shelfwise.co.in in Chrome (desktop)
  2. Chrome will show ⊕ in the URL bar → indicates installable
  3. Login page → you should see the "Install ShelfWise on your phone"
     card below the login form
  4. Click "Install on Desktop" → Chrome shows a native prompt →
     "Install" → app opens in its own window

ANDROID CHROME:
  1. Open shelfwise.co.in on Android phone in Chrome
  2. Banner appears at the top of the app (compact strip)
  3. Tap "Install" → native Android prompt → "Install"
  4. Icon appears on home screen

IPHONE SAFARI:
  1. Open shelfwise.co.in on iPhone in SAFARI (must be Safari)
  2. Banner appears with "Add to iPhone home screen" button
  3. Tap it → modal opens with 3-step guide
  4. Follow steps → icon on home screen

═══════════════════════════════════════════════════════════════════
MARKETING ANGLE — HOW TO USE THIS IN YOUR PITCH
═══════════════════════════════════════════════════════════════════

Old pitch line:
  "Yeh app hai — shelfwise.co.in par jaao"
  (customers think: "another website I have to open every time...")

New pitch line:
  "shelfwise.co.in kholo → 3 second mein Install button dabao →
   phone ke home screen par app aa jayega. WhatsApp jaisa."

Difference: it FEELS like an app now. Same functionality, but the
psychology is completely different. Icon on home screen = it's real.

You can also update your WhatsApp flyer:
  1. Link: shelfwise.co.in
  2. Tap "Install" → done in 3 seconds
  3. Open like any app — no download from Play Store or App Store

═══════════════════════════════════════════════════════════════════
COMMON QUESTIONS
═══════════════════════════════════════════════════════════════════

Q: Why can't iPhone users install with one tap like Android?
A: Apple's rule. They want you to pay them $99/year for the App Store
   and give them 30% of your revenue. So they block all programmatic
   installs for Progressive Web Apps. iPhone users have to do the
   3-tap Share → Add to Home Screen dance.

Q: What if a user is on iPhone but using Chrome/Firefox instead of Safari?
A: They can't install. Chrome/Firefox on iOS use Apple's WebKit engine
   under the hood but can't add to home screen. Our banner detects
   Safari specifically and shows a warning to switch browsers.

Q: Will this replace a native App Store app?
A: For 90% of use cases YES. Payments, camera, notifications, offline
   — all work in a PWA. Only if you need App Store distribution (paid
   apps, in-app purchases) do you need a wrapper. For ShelfWise's
   business kitchen niche, PWA is perfect and saves £99/year + 30% fees.

Q: Can users find ShelfWise in the App Store / Play Store?
A: Not yet — because a PWA isn't listed there. If you want that,
   later we can wrap the PWA using PWABuilder.com (Microsoft's free
   tool) to publish it to Play Store in about 30 minutes. App Store
   is harder because Apple charges. Focus on PWA for now.

— ShelfWise
