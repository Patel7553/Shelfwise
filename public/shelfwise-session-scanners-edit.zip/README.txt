╔══════════════════════════════════════════════════════════════════╗
║  ShelfWise — Scanner Edit + Barcode AI Fallback                  ║
║  Every scanner now lets you EDIT the AI result before saving     ║
╚══════════════════════════════════════════════════════════════════╝

WHAT'S IN THIS UPDATE (2 fixes bundled)
────────────────────────────────────────

  1) 🎤 VOICE SCANNER — now fully editable
     BEFORE: Voice → AI parses → shows read-only cards → Save All (no edit)
     AFTER:  Voice → AI parses → tap any card to expand → edit
             name/qty/unit/expiry/storage/location/category
             → untick to skip individual items → Save

  2) 🔢 BARCODE SCANNER — AI vision fallback (previous session's fix)
     BEFORE: Scan Tesco/Indian product → "not in database" → useless
     AFTER:  Public DB miss → "Snap front of pack" prompt
             → GPT-4o Vision reads label → auto-fills form


SCANNER EDIT SUMMARY (all 5 scanners now have edit):
─────────────────────────────────────────────────────

  ┌──────────────────┬───────────────────────────────────────────┐
  │ Scanner          │ Edit UI                                   │
  ├──────────────────┼───────────────────────────────────────────┤
  │ 📖 Logbook Scan  │ Editable table with keep/skip checkbox    │
  │ 📸 Snap Label    │ Full editable form (SnapDialog)           │
  │ 🔢 Barcode       │ Full editable form (via SnapDialog)       │
  │ 🧾 Receipt Scan  │ Tap-to-expand editable rows               │
  │ 🎤 Voice         │ ⭐ NEW: Tap-to-expand editable cards       │
  └──────────────────┴───────────────────────────────────────────┘


═══════════════════════════════════════════════════════════════════
DEPLOYMENT — 2 STEPS (5 minutes total)
═══════════════════════════════════════════════════════════════════

STEP 1 — REPLACE FILES IN VS CODE (2 min)
──────────────────────────────────────────
  Drag-and-drop these files from the zip → they will OVERWRITE:
    ✓ app/page.js
    ✓ app/api/[[...path]]/route.js

  VS Code should say "Do you want to overwrite?" → click "Yes to All"
  (No database migration needed)

STEP 2 — DEPLOY TO VERCEL (3 min)
──────────────────────────────────
  In VS Code:
    a) Source Control → 2 files changed
    b) Commit message: "Scanners: edit AI results + barcode AI fallback"
    c) ✓ Commit → "Sync Changes"
    d) Wait 2-3 min → refresh shelfwise.co.in

═══════════════════════════════════════════════════════════════════
TESTING CHECKLIST
═══════════════════════════════════════════════════════════════════

VOICE (new edit):
  ☐ Dashboard → 🎤 Voice → speak "add 5 kg chicken expires Friday"
  ☐ AI parses → you see 1 card with name/qty/etc
  ☐ TAP THE CARD → it expands showing editable fields
  ☐ Change quantity from 5 → 10, change name if wrong
  ☐ Also try: untick the checkbox → card greys out
  ☐ Also try: click 🗑️ → row removes
  ☐ Save All → only ticked items save

BARCODE (AI fallback):
  ☐ Scan a Tesco own-brand item
  ☐ If no match in public DB → "Identify by photo" dialog opens
  ☐ Snap front of pack → AI fills form
  ☐ Save → next scan of same code = instant history match

═══════════════════════════════════════════════════════════════════
QUESTIONS?
═══════════════════════════════════════════════════════════════════

If voice items don't expand:
  → Tap ON THE CARD BODY (not on the checkbox or trash icon)

If barcode AI fallback doesn't trigger:
  → Confirm the public databases return no name for that product
  → Or manually enter the code via "Type manually" link in the scanner

— ShelfWise
