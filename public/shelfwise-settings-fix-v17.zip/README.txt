SHELFWISE — SETTINGS SAVE BUG FIX (v17)
========================================

WHAT WAS FIXED
--------------
The Settings dialog was overwriting your saved kitchen name and dashboard widgets
with STALE local state on every save. This happened because:

1. When the Settings dialog opened, it initialized its local state (widgets, name,
   modules) from `settings` — but if `settings` had not yet loaded from the backend,
   the dialog defaulted to "all 12 widgets checked" and "kitchen name = empty".

2. The Save button ALWAYS sent `dashboardWidgets` and `modulesEnabled` in the payload,
   even if you never opened the Dashboard tab. So saving Profile changes would
   overwrite your Dashboard widget selection with the stale defaults.

3. Result: unchecking a widget would appear to fail on the next save, and the
   kitchen name kept reverting to "My Kitchen" / "ShelfWise".

THE FIX (v17)
-------------
I switched the dialog to strict PATCH semantics with per-section "touched" tracking:

- Each of the 4 tabs (Profile, Login, Dashboard, Fields) has its own dirty flag.
- Any input change on that tab marks its section as touched.
- On Save, ONLY touched sections are sent to the backend. Untouched sections are
  omitted, so the backend keeps whatever's in the DB.
- If the dialog opens before settings finishes loading, the useEffect now re-syncs
  the untouched sections as soon as settings arrives. Sections the user has
  already touched are preserved.
- Kitchen name is never sent as an empty string.
- If nothing was touched, Save is a no-op (just closes the dialog).

FILES CHANGED
-------------
- app/page.js (only file changed)

HOW TO APPLY
------------
1. Open your local ShelfWise project in VS Code.
2. Drag /app/page.js from this zip into your project's `app/` folder, replacing
   the existing file.
3. Commit and push to Vercel (or however you deploy).
4. Test:
   a) Open Settings, go to Dashboard tab.
   b) Uncheck a card. Click Save All.
   c) Refresh the page. The unchecked card should stay hidden.
   d) Kitchen name should NOT change back to "ShelfWise" or "My Kitchen".

Also test Profile-only saves:
   a) Open Settings, ONLY change Kitchen Type dropdown.
   b) Click Save All.
   c) Confirm Dashboard widgets are untouched (still whatever you set previously).
