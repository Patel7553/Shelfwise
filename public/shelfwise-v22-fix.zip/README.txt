SHELFWISE — v22 (User's Own Fridge Names Everywhere)
=====================================================

WHAT'S FIXED IN V22
-------------------
The manual "Log temperature" modal was hardcoded to show:
   "Fridge 1", "Fridge 2", "Fridge 3", "Freezer 1", "Freezer 2",
   "Walk-in Cold Room", "Hot Hold", "Display Cabinet"

Now it shows ONLY the fridges/freezers YOU added in
   Settings → Fridges & Freezers

Behaviour:
- If you have configured locations → dropdown lists them (with type icons ❄️🥶🔥🧊).
- If you have NONE configured yet → free-text input + a friendly hint pointing you
  to Settings → Fridges & Freezers.

Also updated migration-12 to NO LONGER seed default "Main Fridge / Main Freezer"
locations — users add their own so the names always reflect their kitchen.

FILES CHANGED
-------------
- app/page.js (temp modal location picker now uses haccpLocations)
- supabase/migration-12-haccp-locations.sql (removed seed data)

⚠️  IF YOU ALREADY RAN MIGRATION-12
-----------------------------------
Two seeded rows ("Main Fridge" and "Main Freezer") may still be in your kitchen
row. Just open Settings → Fridges & Freezers and delete/rename them.

If you WANT to remove the seeded rows in bulk via SQL (optional):
   UPDATE kitchens
      SET haccp_locations = '[]'::jsonb
    WHERE haccp_locations @> '[{"id":"seed-fridge-1"}]'
       OR haccp_locations @> '[{"id":"seed-freezer-1"}]';

If you haven't run the migration yet, use the NEW v22 version — it just adds
the column without any seed data.

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

TESTING
-------
1. Settings → Fridges & Freezers → add YOUR real fridge/freezer names
   (e.g. "Patients fridge", "Support fridge", "Walk-in freezer").
2. Save All → close.
3. HACCP → Temperatures → "Log temperature".
4. The location dropdown should now show ONLY your saved fridges, each with
   its type icon.
5. Scan a sheet — AI will match handwritten labels to your saved names.

INCLUDES CARRY-OVERS FROM V17-V21
---------------------------------
- Settings save (patch-style)
- Fridges & Freezers manager (unlimited units)
- Universal HACCP scanner (fuzzy matching to your saved names)
- 60s Vercel timeout + client-side image compression
- Beautiful weekly logbook grid view + list view toggle + print
