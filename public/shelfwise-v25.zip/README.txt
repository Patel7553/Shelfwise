SHELFWISE — v25 (Free-text Location + Unmatched Row Warning)
=============================================================

WHY YOUR TWO ISSUES HAPPENED
----------------------------

Issue 1: "I want to change Ward but I can't"
  Cause: The Edit modal used a DROPDOWN with only your saved fridges.
  If the reading's location was "Ward" but your saved list had
  "Ward Fridge", the dropdown couldn't show or accept "Ward" — you
  were stuck.

Issue 2: "Only 2 fridges in Logbook?"
  Cause: The Logbook grid only showed fridges from your Settings list.
  Any reading whose location didn't match a saved name (e.g. AI scan
  wrote "Ward" but you have "Ward Fridge") was HIDDEN from the grid.
  So it looked like readings had vanished — they were just invisible.

WHAT V25 FIXES
--------------

1) 📝 LOCATION FIELD IS NOW A FREE-TEXT INPUT + AUTOCOMPLETE
   The Log/Edit temperature modal's Location field is now:
     * Text input — type ANY name you want (rename "Ward" → "Ward Fridge",
       or use a name that isn't in your saved list at all).
     * Autocomplete dropdown of your saved fridges (browser datalist).
     * Quick-pick pills below — tap any saved fridge to fill in its name.
   Selected quick-pick is highlighted green so you can see which one is picked.

2) ⚠️ "UNMATCHED" ROWS SHOWN IN LOGBOOK GRID
   The Logbook grid now shows TWO groups of rows:
     * Your configured fridges (normal white/gray rows)
     * ⚠️ UNMATCHED locations from readings (amber-tinted rows with a
       yellow "Unmatched" pill next to the name)
   An amber warning banner appears above the grid listing all unmatched
   names with a fix suggestion.
   → You can now SEE all your readings, know which ones need renaming,
     and fix them via the List view (✏️ edit → type the exact saved name).

3) 🖨️ PRINTED SHEETS STILL ONLY SHOW YOUR NAMED FRIDGES
   The physical printout (Print button) STILL excludes unmatched rows —
   your compliance record stays clean. The unmatched warning is
   on-screen only, purely for you to spot & fix inconsistencies.

TYPICAL FIX FLOW (once v25 is deployed):
  1. Notice the amber "1 reading has a location that doesn't match" banner.
  2. Switch to List view.
  3. Find the "Ward ..." reading → tap ✏️ pencil → type your exact name
     (e.g. "Ward Fridge") or tap a quick-pick pill → Update.
  4. Return to Logbook → banner disappears, row now under correct fridge.

FILES CHANGED
-------------
- app/page.js only (no backend / DB changes)

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

INCLUDES CARRY-OVERS FROM V17-V24
---------------------------------
- Settings save (patch-style, touched-tracking)
- Fridges & Freezers manager (unlimited, user-named)
- Universal HACCP scanner (fuzzy-match + your saved names as context)
- 60s Vercel timeout + client-side image compression (2200px @ 0.86)
- Weekly logbook grid + list toggle + edit/multi-delete
- Print blank template + landscape/portrait toggle
- Graceful backend fallback if migration-12 hasn't been run
