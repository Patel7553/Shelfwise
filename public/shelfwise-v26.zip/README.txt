SHELFWISE — v26 (One-Tap "Add Unmatched to My Fridges")
========================================================

WHAT THE AMBER WARNING MEANT
----------------------------
Your Settings > Fridges & Freezers had only "Main Fridge" and "Main Freezer"
(the seeded defaults). But your scanned readings had 17 different real
names ("Ward 1 Fridge", "Patients fridge", "Support fridge", etc.).

Since none of the scanned names matched your Settings list, they were shown
as "Unmatched" amber rows with the warning.

V26 FIX — ONE-TAP RESOLUTION
----------------------------
The amber warning banner now has a BIG button:

  [ ✨ Add all N to my fridges (one-tap fix) ]

Tap it once and:
  1. All unmatched location names are added to your Fridges & Freezers list.
  2. Each is auto-typed as Fridge or Freezer based on the temperature sign
     (negative temps → Freezer, positive → Fridge).
  3. Settings is saved via PUT /api/settings.
  4. The page reloads so the Logbook grid now shows every reading in the
     correct row — no more "Unmatched" pills.

You can still fine-tune afterward:
  * Settings → Fridges & Freezers → rename anything (e.g. "Ward 1 Fridge"
    → "Ward Fridge Room 1"), change type, or delete any you don't want.

TYPICAL FLOW FOR YOUR CURRENT STATE
-----------------------------------
1. Deploy v26 (Save to GitHub → Vercel).
2. Go to HACCP → Temperatures.
3. See amber banner listing your 17 unmatched names.
4. Tap "✨ Add all 17 to my fridges" → wait 1-2 seconds → page reloads.
5. Now the Logbook shows all 17 real fridges as proper rows.
6. Go to Settings → Fridges & Freezers → delete "Main Fridge" and
   "Main Freezer" (the seed data) if you want, and rename/adjust types
   for any of the newly added ones.
7. Save All.

WHY THE ONE-TAP APPROACH IS GOOD
--------------------------------
- Manual: typing 17 names one at a time is painful.
- Manual: risks typos so scanning would re-flag them as unmatched.
- Automatic: uses the EXACT name that the AI read from your sheet,
  guaranteeing 100% match rate on future scans.

FILES CHANGED
-------------
- app/page.js only (no backend / DB changes)

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

REQUIREMENT
-----------
Migration-12 MUST have been run in Supabase already. If you see:
  "Fridges & Freezers list could not be saved — please run migration-12"
then open Supabase → SQL Editor → run:
  ALTER TABLE kitchens
    ADD COLUMN IF NOT EXISTS haccp_locations JSONB NOT NULL DEFAULT '[]'::jsonb;

INCLUDES CARRY-OVERS FROM V17-V25
---------------------------------
- Settings save (patch-style, touched-tracking)
- Fridges & Freezers manager with multi-delete
- Universal HACCP scanner (fuzzy-match + your saved names as context)
- Higher-quality image compression (2200px @ 0.86)
- Weekly logbook grid + list toggle + edit temperature readings
- Print blank template + landscape/portrait toggle + close button
- Free-text location input with autocomplete + quick-pick pills
- Unmatched-reading detection with amber warning
