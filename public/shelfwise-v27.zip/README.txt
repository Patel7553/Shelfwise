SHELFWISE — v27 (Tap-to-Log Directly in Logbook Grid)
======================================================

NEW FEATURE
-----------
Tap ANY cell in the Logbook grid to log a temperature directly for that
fridge/day/AM-or-PM slot. No more hunting for "Log temperature" button.

HOW IT WORKS
------------
Empty cells (dashes "—") are replaced with a subtle "+" icon.
  * Tap an empty AM cell for e.g. "Main Fridge" on Wed 08/07:
    → Modal opens PRE-FILLED with:
        Location = Main Fridge
        Date     = 08/07/2026
        Time     = 08:00 (AM)
    → You just type the temp value and tap Save. Two taps total.

Cells that already have readings (green PASS / red FAIL values):
  * Tap them → opens the edit modal for that reading.
  * Modal shows the location + current temp + date/time + PASS/FAIL.

VISUAL POLISH
-------------
* Empty cells show "+" instead of "—" and highlight green on hover.
* Filled cells get a green ring on hover so you know they're editable.
* Legend at the bottom now says:
     "🟢 Pass · 🔴 Fail · + Tap empty cell to add · tap value to edit"

TYPICAL WORKFLOW (once v27 is deployed)
---------------------------------------
Morning check (8am):
  1. Open ShelfWise → HACCP → Temperatures.
  2. In Logbook view, find your row (e.g. "Main Fridge") + today's AM column.
  3. Tap the "+" cell → modal opens with everything pre-filled.
  4. Type "4.2" → tap Save. Done.
  5. Cell now shows "4.2" in green.

Evening check (5pm):
  1. Same row, tap PM column's "+" cell → modal opens for 17:00.
  2. Type "3.8" → Save. Done.

Repeat for each fridge. The grid becomes your daily checklist.

BENEFITS
--------
- No more manual "Location" dropdown (already picked from the row).
- No more "Date" picker (already picked from the column).
- No more "AM/PM" toggle (already picked from the sub-column).
- Just type the number, hit Save. That's it.

FILES CHANGED
-------------
- app/page.js only (no backend / DB changes)

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

INCLUDES CARRY-OVERS FROM V17-V26
---------------------------------
- Settings save (patch-style)
- Fridges & Freezers manager with multi-delete
- Universal HACCP scanner + fuzzy-match
- Higher-quality image compression (2200px @ 0.86)
- Weekly logbook grid + list toggle + edit temp readings
- Print blank template + landscape/portrait toggle
- Free-text location input with autocomplete + quick-pick pills
- One-tap "Add unmatched to my fridges" bulk fix
