SHELFWISE — v30 (Multi-Delete in Temperature List)
===================================================

WHAT'S NEW
----------
The Temperature List view now has bulk-select and multi-delete —
just like the Fridges & Freezers manager in Settings.

HOW IT WORKS
------------
1) Each row now has a checkbox on the left.
2) A "Select all (N)" toggle above the list.
3) Tick any row(s) — a red toolbar appears at the top:

    [ 15 selected ]                    [ Cancel ]  [ 🗑️ Delete selected ]

4) Tap "Delete selected" → confirmation dialog → all selected readings
   are removed from Supabase.
5) Selected rows have a red ring highlight so you know what's about
   to be deleted.

USE CASES
---------
* After a bulk AI scan brought in duplicate or wrong readings — select them
  all and delete in one shot.
* Cleaning up old test data — Select all → Delete selected.
* Removing a bad batch of readings from a specific date.

INDIVIDUAL EDIT / DELETE STILL AVAILABLE
----------------------------------------
Each row still has the ✏️ pencil (edit) and 🗑️ trash (single delete) icons.
Multi-delete is an addition, not a replacement.

FILES CHANGED
-------------
- app/page.js only (no backend / DB changes)

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

TESTING
-------
1. HACCP → Temperatures → List view.
2. Tick 3-5 rows.
3. Red toolbar appears at the top.
4. Tap "Delete selected" → confirm → they vanish.

INCLUDES CARRY-OVERS FROM V17-V29
---------------------------------
- All previous features preserved:
  * Settings save (patch-style with touched-tracking)
  * Fridges & Freezers manager (unlimited names, multi-delete)
  * Universal HACCP scanner (fuzzy match to your saved names)
  * Higher-quality image compression (2200px @ 0.86)
  * Weekly logbook grid + inline cell editing (Enter to save)
  * Quick Check dialog (all fridges in one form)
  * AM/PM/Now toggle + date picker in Log modal
  * Print blank/filled + landscape/portrait toggle + close button
  * Free-text location input with autocomplete + quick-pick pills
  * One-tap "Add unmatched to my fridges" bulk fix
