SHELFWISE — v31 (True Bulk Delete — ONE confirmation, done)
============================================================

WHAT V31 FIXES
--------------
Previous v30 bulk delete secretly triggered 14 separate "Delete this record?"
popups (one per selected row) because each delete used the same shared
per-row confirm() dialog.

Now bulk delete works like a real bulk operation:

  Select 14 rows → tap "Delete selected"
       ↓
  ONE confirmation popup: "Delete 14 records? This cannot be undone."
       ↓
  Tap OK → all 14 delete in the background (silent, no per-row prompts)
       ↓
  ONE toast: "Deleted 14 records"
       ↓
  List refreshes.

HOW IT WORKS UNDER THE HOOD
---------------------------
* `deleteRow(kind, id, { silent: true })` now bypasses the per-row confirm
  and per-row toast when called from bulk operations.
* New `bulkDelete(kind, ids)` handles the whole flow:
    - ONE confirmation before starting.
    - Runs deletions in sequence (silent mode).
    - Counts successes/failures.
    - Shows ONE summary toast: "Deleted N (or N deleted, M failed)".
    - Calls load() ONCE at the end (not N times).

INDIVIDUAL DELETE STILL WORKS
-----------------------------
Clicking the 🗑️ icon on a single row still asks its own "Delete this record?"
confirmation (as expected).

FILES CHANGED
-------------
- app/page.js only

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

TESTING
-------
1. HACCP → Temperatures → List view.
2. Tap "Select all (N)".
3. Tap 🗑️ Delete selected in the red toolbar.
4. ONE popup: "Delete N records? This cannot be undone." → OK.
5. All N gone instantly. Single toast confirms.

INCLUDES CARRY-OVERS FROM V17-V30
---------------------------------
All prior features preserved.
