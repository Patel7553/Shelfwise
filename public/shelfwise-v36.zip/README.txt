SHELFWISE — v36 (Clean HACCP Dashboard, No Defaults)
=====================================================

WHAT CHANGED
------------

1) REMOVED "Today's Fridge Status" panel from HACCP Compliance page.
   The page is now clean again — just the 4 summary cards + tabs
   (Temperatures / Cleaning / Deliveries).

2) CONFIRMED: NO hardcoded default fridges anywhere in the code.
   * Migration-12 no longer seeds "Main Fridge" or "Main Freezer".
   * No fallback dropdown defaults ("Fridge 1", "Fridge 2", etc.) exist.
   * Users start with a completely EMPTY fridge list — they add only
     what they need.

3) The user's saved fridges still appear in these places (unchanged):
   * Settings → Fridges & Freezers (where they manage the list).
   * HACCP → Temperatures → Logbook view (rows).
   * HACCP → Temperatures → Log temperature modal (autocomplete + pills).
   * HACCP → Temperatures → Quick Check dialog (list of all).
   * Print blank / filled logbook (rows).

CLEANING UP EXISTING SEEDED DATA (if any)
-----------------------------------------
If your kitchen already has "Main Fridge" and "Main Freezer" from an
earlier migration seed, delete them manually:
  1. Settings → Fridges & Freezers.
  2. Tick the checkbox next to "Main Fridge" and "Main Freezer".
  3. Tap the red "Delete selected" button.
  4. Tap Save All.

Or via Supabase SQL:
  UPDATE kitchens
     SET haccp_locations = (
       SELECT jsonb_agg(elem)
       FROM jsonb_array_elements(haccp_locations) elem
       WHERE elem->>'id' NOT LIKE 'seed-%'
     );

FILES CHANGED
-------------
- app/page.js only (removed the Today's Fridge Status card)

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

INCLUDES CARRY-OVERS FROM V17-V35
---------------------------------
All prior features preserved.
