SHELFWISE — v42 (Just the Name-Match Fix, No AI Change)
========================================================

WHAT V42 CONTAINS
-----------------
* NAME-MATCHING FIX ONLY (safe, no cost impact).
* AI model STAYS on gpt-4o-mini (unchanged from v40).

WHAT'S THE NAME-MATCHING FIX?
-----------------------------
Previously the "unmatched" warning fired even when fridge names looked
identical. Cause: tiny differences (extra spaces, hyphens, punctuation,
mixed case) failed the equality check.

V42 normalizes both sides before comparing:
  * Lowercase everything.
  * Replace all non-alphanumeric chars (spaces, hyphens, slashes,
    apostrophes, punctuation) with single spaces.
  * Trim leading/trailing whitespace.

Result — ALL these variants now match cleanly:
  "Ward Fridge"  =  "ward-fridge"
                 =  "Ward  Fridge"   (double space)
                 =  "ward fridge "   (trailing space)
                 =  "WARD FRIDGE"    (uppercase)
                 =  "ward/fridge"    (with slash)

WHAT V42 DOES NOT CONTAIN
-------------------------
* Claude Sonnet model switch (postponed — awaiting your decision).
* Any credit/pricing changes.

FILES CHANGED
-------------
- app/page.js (aggressive name-match normalization in TempLogbookView)

HOW TO DEPLOY
-------------
Click "Save to GitHub" → Vercel auto-deploys in ~2 min.

WHAT YOU CAN TEST WITHOUT MORE CREDITS
--------------------------------------
1. Deploy v42.
2. Add a fridge named exactly "Ward Fridge" in Settings.
3. Manually log a temp with location "ward fridge" or "Ward-Fridge".
4. Confirm NO unmatched warning appears anymore.

WHEN YOU'RE READY FOR CLAUDE (LATER)
------------------------------------
Just tell me "switch to Claude" and I'll do it in 1 minute — model
name change only. All other logic stays the same.

Or if you'd rather try gpt-4o (full-size, middle-ground price/quality),
just say the word.

INCLUDES CARRY-OVERS FROM V17-V41
---------------------------------
All prior features preserved except the Claude switch.
